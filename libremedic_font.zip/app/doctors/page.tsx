"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Plus,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Calendar,
  Phone,
  Mail,
  Stethoscope,
  Award,
  Clock,
} from "lucide-react"
import { AppSidebar } from "@/components/app-sidebar"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Datos de ejemplo de médicos
const doctors = [
  {
    id: 1,
    name: "Dr. Juan Pérez",
    email: "juan.perez@libremedic.com",
    phone: "+34 612 345 678",
    specialty: "Cardiología",
    license: "COL-12345",
    experience: 15,
    status: "Activo",
    schedule: "Lunes a Viernes 9:00-17:00",
    patients: 156,
    consultations: 1240,
    rating: 4.8,
    medicalCenter: "Hospital Central",
  },
  {
    id: 2,
    name: "Dra. Ana López",
    email: "ana.lopez@libremedic.com",
    phone: "+34 623 456 789",
    specialty: "Pediatría",
    license: "COL-23456",
    experience: 12,
    status: "Activo",
    schedule: "Lunes a Viernes 8:00-16:00",
    patients: 203,
    consultations: 1580,
    rating: 4.9,
    medicalCenter: "Clínica San Rafael",
  },
  {
    id: 3,
    name: "Dr. Miguel Torres",
    email: "miguel.torres@libremedic.com",
    phone: "+34 634 567 890",
    specialty: "Neurología",
    license: "COL-34567",
    experience: 20,
    status: "Vacaciones",
    schedule: "Martes y Jueves 10:00-18:00",
    patients: 89,
    consultations: 890,
    rating: 4.7,
    medicalCenter: "Hospital Universitario",
  },
  {
    id: 4,
    name: "Dra. Carmen Ruiz",
    email: "carmen.ruiz@libremedic.com",
    phone: "+34 645 678 901",
    specialty: "Ginecología",
    license: "COL-45678",
    experience: 8,
    status: "Activo",
    schedule: "Lunes a Miércoles 9:00-15:00",
    patients: 134,
    consultations: 670,
    rating: 4.6,
    medicalCenter: "Centro Médico Femenino",
  },
]

const specialties = ["Cardiología", "Pediatría", "Neurología", "Ginecología", "Medicina General", "Dermatología"]

export default function DoctorsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSpecialty, setSelectedSpecialty] = useState("")

  const filteredDoctors = doctors.filter(
    (doctor) =>
      (doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (selectedSpecialty === "" || doctor.specialty === selectedSpecialty),
  )

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-2 h-4" />
          <h1 className="text-xl font-semibold">Gestión de Médicos</h1>
        </header>

        <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
          {/* Header con búsqueda y acciones */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar médicos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 w-[300px]"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Médico
            </Button>
          </div>

          {/* Estadísticas rápidas */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Médicos</CardTitle>
                <Stethoscope className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{doctors.length}</div>
                <p className="text-xs text-muted-foreground">+1 nuevo este mes</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Médicos Activos</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{doctors.filter((d) => d.status === "Activo").length}</div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((doctors.filter((d) => d.status === "Activo").length / doctors.length) * 100)}% del total
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Especialidades</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{specialties.length}</div>
                <p className="text-xs text-muted-foreground">Diferentes especialidades</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consultas Hoy</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">47</div>
                <p className="text-xs text-muted-foreground">Programadas para hoy</p>
              </CardContent>
            </Card>
          </div>

          {/* Tabla de médicos */}
          <Card>
            <CardHeader>
              <CardTitle>Lista de Médicos</CardTitle>
              <CardDescription>Gestiona la información de todos los médicos registrados</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Médico</TableHead>
                    <TableHead>Especialidad</TableHead>
                    <TableHead>Contacto</TableHead>
                    <TableHead>Experiencia</TableHead>
                    <TableHead>Pacientes</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead className="text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDoctors.map((doctor) => (
                    <TableRow key={doctor.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center space-x-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={`/placeholder-user.jpg`} />
                            <AvatarFallback className="bg-blue-600 text-white">
                              {doctor.name
                                .split(" ")
                                .slice(0, 2)
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{doctor.name}</div>
                            <div className="text-sm text-muted-foreground">{doctor.license}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {doctor.specialty}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center text-sm">
                            <Mail className="h-3 w-3 mr-1" />
                            {doctor.email}
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Phone className="h-3 w-3 mr-1" />
                            {doctor.phone}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{doctor.experience} años</TableCell>
                      <TableCell>
                        <div className="text-center">
                          <div className="font-medium">{doctor.patients}</div>
                          <div className="text-xs text-muted-foreground">pacientes</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className="text-yellow-500 mr-1">★</span>
                          <span className="font-medium">{doctor.rating}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            doctor.status === "Activo"
                              ? "default"
                              : doctor.status === "Vacaciones"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {doctor.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              Ver Perfil
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Calendar className="mr-2 h-4 w-4" />
                              Ver Horarios
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Stethoscope className="mr-2 h-4 w-4" />
                              Historial Consultas
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
